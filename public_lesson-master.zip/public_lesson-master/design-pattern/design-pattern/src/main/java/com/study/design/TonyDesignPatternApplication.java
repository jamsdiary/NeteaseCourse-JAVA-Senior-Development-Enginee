package com.study.design;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TonyDesignPatternApplication {

	public static void main(String[] args) {
		SpringApplication.run(TonyDesignPatternApplication.class, args);
	}
}
