package com.study.dubbo;

/**
 * ʾ��
 *
 */
public interface DemoService {
	String test(String value);
}
