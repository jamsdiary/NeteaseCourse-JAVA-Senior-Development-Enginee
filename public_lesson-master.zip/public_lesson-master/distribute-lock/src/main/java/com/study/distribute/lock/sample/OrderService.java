package com.study.distribute.lock.sample;

public interface OrderService {
	void createOrder();
}
