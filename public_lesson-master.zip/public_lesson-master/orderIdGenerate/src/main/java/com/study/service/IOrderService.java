package com.study.service;

/**
 * 订单接口
 * 
 * @author allen
 *
 */
public interface IOrderService {
	/**
	 * 获取订单号
	 */
	public void orderId();
}
