package com.study.rabbitmq.service;

import com.study.rabbitmq.model.User;

public interface UserService {
 
	public User getUser(String id);
}
