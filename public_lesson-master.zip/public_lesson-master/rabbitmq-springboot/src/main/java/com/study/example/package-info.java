package com.study.example;

// direct：转发消息到routigKey指定的队列

// topic：按规则转发消息（最灵活）

// fanout：转发消息到所有绑定队列

// headers：（和direct一样，性能还差基本用不到）