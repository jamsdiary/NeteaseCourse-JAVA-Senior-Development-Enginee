package com.study.rwdb;

/**
 * 读写操作对应数据源
 * 
 * @author allen
 *
 */
public enum DynamicDataSourceGlobal {
    READ, WRITE;
}
