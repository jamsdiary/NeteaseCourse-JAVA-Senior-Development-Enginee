package com.study.thread.demo1;

public class Test {
    public static void main(String[] args) {
        // 搜索 2018面试题  哪些知识点你需要准备
        // 多线程面试题： java 锁 面试题
        // 前因后果
        // 锁-> 线程的状态
    }
}
