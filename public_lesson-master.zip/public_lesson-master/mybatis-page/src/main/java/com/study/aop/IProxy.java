package com.study.aop;

/**
 * 定义代理接口
 * 
 * @author allen
 *
 */
public interface IProxy {
	
	// 买票
	public void buyTicket();
	
}
