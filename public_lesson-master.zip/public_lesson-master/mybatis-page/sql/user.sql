
create table `user` (
	`id` int (11),
	`userName` varchar (150),
	`userAge` varchar (150),
	`userAddress` varchar (300)
); 
insert into `user` (`id`, `userName`, `userAge`, `userAddress`) values('1','zhangsan','18','hunan.changsha');
insert into `user` (`id`, `userName`, `userAge`, `userAddress`) values('2','lisi','19','hunan.changsha');
insert into `user` (`id`, `userName`, `userAge`, `userAddress`) values('3','wangwu','20','hunan.changsha');
insert into `user` (`id`, `userName`, `userAge`, `userAddress`) values('4','zhaoliu','21','hunan.changsha');
insert into `user` (`id`, `userName`, `userAge`, `userAddress`) values('5','zhangsan2','22','beijing');
insert into `user` (`id`, `userName`, `userAge`, `userAddress`) values('6','lisi2','23','beijing');
