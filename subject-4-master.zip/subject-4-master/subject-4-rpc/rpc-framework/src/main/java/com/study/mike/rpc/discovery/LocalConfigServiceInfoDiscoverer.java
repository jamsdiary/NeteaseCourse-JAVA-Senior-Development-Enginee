package com.study.mike.rpc.discovery;

import java.util.List;

public class LocalConfigServiceInfoDiscoverer implements ServiceInfoDiscoverer {

	@Override
	public List<ServiceInfo> getServiceInfo(String name) {
		// TODO Auto-generated method stub
		return null;
	}

}
