package com.study.mike.rpc.common.protocol;

public class HttpMessageProtocol implements MessageProtocol {

	@Override
	public byte[] marshallingRequest(Request req) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Request unmarshallingRequest(byte[] data) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public byte[] marshallingResponse(Response rsp) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Response unmarshallingResponse(byte[] data) {
		// TODO Auto-generated method stub
		return null;
	}

}
