package com.study.mike.rpc.client.net;

import com.study.mike.rpc.discovery.ServiceInfo;

public class BioNetClient implements NetClient {

	@Override
	public byte[] sendRequest(byte[] data, ServiceInfo sinfo) {
		// TODO Auto-generated method stub
		return null;
	}

}
