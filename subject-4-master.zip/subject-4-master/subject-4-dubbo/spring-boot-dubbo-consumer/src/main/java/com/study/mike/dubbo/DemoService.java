package com.study.mike.dubbo;

public interface DemoService {
	String sayHello(String name);
}
