# 专题五——云课堂后端项目 #
·  

## 点击头像添加老师咨询 ##
|Tony|Mike|Allen|
|------|------|------|
|[![加QQ](https://file.service.qq.com/user-files/uploads/201612/c7247c8c83eaad9b768249f54eba3c19.png)](http://wpa.qq.com/msgrd?v=3&uin=895765426&site=qq&menu=yes "加Tony老师咨询")|[![加QQ](https://file.service.qq.com/user-files/uploads/201612/c7247c8c83eaad9b768249f54eba3c19.png)](http://wpa.qq.com/msgrd?v=3&uin=442178464&site=qq&menu=yes "加Mike老师咨询")|[![加QQ](https://file.service.qq.com/user-files/uploads/201612/c7247c8c83eaad9b768249f54eba3c19.png)](http://wpa.qq.com/msgrd?v=3&uin=422539792&site=qq&menu=yes "加Allen老师咨询")|

·  

|子项目|项目描述信息|
|------|------|
|[subject-5-develop-specifications](./subject-5-develop-specifications)|专题五 devops规范|
|[subject-5-jenkins](./subject-5-jenkins)|专题五 jenkins|
|[subject-5-cloudstudy](./subject-5-cloudstudy)|专题五 后端项目实战|
|[subject-5-zabbix](./subject-5-zabbix)|专题五 zabbix线上监控|
|[subject-5-git](./subject-5-git)|专题五 git版本管理工具|
