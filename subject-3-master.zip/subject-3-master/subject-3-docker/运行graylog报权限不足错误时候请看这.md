graylog在root用户下，使用github上下载的docker-compose.yml启动时出现Operation not permitted错误
---
请参考gitlab上解决方案：  
[http://59.111.92.219/java-q1901/subject-3-docker/issues/1](http://59.111.92.219/java-q1901/subject-3-docker/issues/1)